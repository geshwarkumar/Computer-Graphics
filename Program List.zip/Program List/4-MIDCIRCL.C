/*C PROGRAM TO DRAW CIRCLE USING MIDPOINT ALGORITHM
-GESHWAR KUMAR
-03/08/2017*/
#include<graphics.h>
//#include<math.h>
void main(){
	/*DECLARATION*/
	int *gd=DETECT, *gm ;
	int x, y, xinc=0, yinc=0 ;
	int steps, radius,iter ;
	/*INITIATE GRAPHICS*/
	initgraph(&gd, &gm, "C:\\TC\\BGI");
	/*CLEAR OUTPUT SCREEN*/
	cleardevice();
	radius = 200 ;
	x = 0 , y = radius ;

	steps = (5 / 4) - radius ;

	for(iter=0;iter<y;iter++){
		putpixel(x,y,WHITE);
		putpixel(y,x,RED);
		printf("%d<=>%d ",x,y);
		//putpixel(-y,x,CYAN);
		if(steps < 0){
			xinc = 1 ;
			yinc = 0 ;
			steps = steps + (2 * x) + 3 ;
		}
		else{
			xinc = 1 ;
			yinc = 1 ;
			steps = steps + 2 * (x - y) + 5 ;
		}
		x = x + xinc ;
		y = y - yinc ;
		//printf("%d-%d\n",x,y);
		//putpixel(x,y,WHITE);
		/*putpixel(y,x,RED);
		putpixel(-y,x,WHITE);*/
	}

getch();
closegraph();
}